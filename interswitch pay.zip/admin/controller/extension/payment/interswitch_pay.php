<?php
class ControllerExtensionPaymentInterswitchPay extends Controller
{
    private $error = array();

    public function index()
    {
        $this->load->language('extension/payment/interswitch_pay');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('payment_interswitch_pay', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['email'])) {
            $data['error_email'] = $this->error['email'];
        } else {
            $data['error_email'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true),
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true),
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/payment/interswitch_pay', 'user_token=' . $this->session->data['user_token'], true),
        );

        $data['action'] = $this->url->link('extension/payment/interswitch_pay', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

        if (isset($this->request->post['payment_interswitch_pay_email'])) {
            $data['payment_interswitch_pay_email'] = $this->request->post['payment_interswitch_pay_email'];
        } else {
            $data['payment_interswitch_pay_email'] = $this->config->get('payment_interswitch_pay_email');
        }

        if (isset($this->request->post['payment_interswitch_pay_test'])) {
            $data['payment_interswitch_pay_test'] = $this->request->post['payment_interswitch_pay_test'];
        } else {
            $data['payment_interswitch_pay_test'] = $this->config->get('payment_interswitch_pay_test');
        }

        // Gate Way
        if (isset($this->request->post['payment_interswitch_pay_url'])) {
            $data['payment_interswitch_pay_url'] = $this->request->post['payment_interswitch_pay_url'];
        } else {
            $data['payment_interswitch_pay_url'] = $this->config->get('payment_interswitch_pay_url');
        }

        // Merchant Code
        if (isset($this->request->post['payment_interswitch_pay_merchant_code'])) {
            $data['payment_interswitch_pay_merchant_code'] = $this->request->post['payment_interswitch_pay_merchant_code'];
        } else {
            $data['payment_interswitch_pay_merchant_code'] = $this->config->get('payment_interswitch_pay_merchant_code');
        }

        // Domain Code
        if (isset($this->request->post['payment_interswitch_pay_domain_code'])) {
            $data['payment_interswitch_pay_domain_code'] = $this->request->post['payment_interswitch_pay_domain_code'];
        } else {
            $data['payment_interswitch_pay_domain_code'] = $this->config->get('payment_interswitch_pay_domain_code');
        }

        // Currency Code
        if (isset($this->request->post['payment_interswitch_pay_currency_code'])) {
            $data['payment_interswitch_pay_currency_code'] = $this->request->post['payment_interswitch_pay_currency_code'];
        } else {
            $data['payment_interswitch_pay_currency_code'] = $this->config->get('payment_interswitch_pay_currency_code');
        }

        // Terminal Id
        if (isset($this->request->post['payment_interswitch_pay_terminal_id'])) {
            $data['payment_interswitch_pay_terminal_id'] = $this->request->post['payment_interswitch_pay_terminal_id'];
        } else {
            $data['payment_interswitch_pay_terminal_id'] = $this->config->get('payment_interswitch_pay_terminal_id');
        }


        // Provider Icon Url
        if (isset($this->request->post['payment_interswitch_pay_provider_icon_url'])) {
            $data['payment_interswitch_pay_provider_icon_url'] = $this->request->post['payment_interswitch_pay_provider_icon_url'];
        } else {
            $data['payment_interswitch_pay_provider_icon_url'] = $this->config->get('payment_interswitch_pay_provider_icon_url');
        }

        if (isset($this->request->post['payment_interswitch_pay_transaction'])) {
            $data['payment_interswitch_pay_transaction'] = $this->request->post['payment_interswitch_pay_transaction'];
        } else {
            $data['payment_interswitch_pay_transaction'] = $this->config->get('payment_interswitch_pay_transaction');
        }

        if (isset($this->request->post['payment_interswitch_pay_debug'])) {
            $data['payment_interswitch_pay_debug'] = $this->request->post['payment_interswitch_pay_debug'];
        } else {
            $data['payment_interswitch_pay_debug'] = $this->config->get('payment_interswitch_pay_debug');
        }

        if (isset($this->request->post['payment_interswitch_pay_total'])) {
            $data['payment_interswitch_pay_total'] = $this->request->post['payment_interswitch_pay_total'];
        } else {
            $data['payment_interswitch_pay_total'] = $this->config->get('payment_interswitch_pay_total');
        }

        if (isset($this->request->post['payment_interswitch_pay_canceled_reversal_status_id'])) {
            $data['payment_interswitch_pay_canceled_reversal_status_id'] = $this->request->post['payment_interswitch_pay_canceled_reversal_status_id'];
        } else {
            $data['payment_interswitch_pay_canceled_reversal_status_id'] = $this->config->get('payment_interswitch_pay_canceled_reversal_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_completed_status_id'])) {
            $data['payment_interswitch_pay_completed_status_id'] = $this->request->post['payment_interswitch_pay_completed_status_id'];
        } else {
            $data['payment_interswitch_pay_completed_status_id'] = $this->config->get('payment_interswitch_pay_completed_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_denied_status_id'])) {
            $data['payment_interswitch_pay_denied_status_id'] = $this->request->post['payment_interswitch_pay_denied_status_id'];
        } else {
            $data['payment_interswitch_pay_denied_status_id'] = $this->config->get('payment_interswitch_pay_denied_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_expired_status_id'])) {
            $data['payment_interswitch_pay_expired_status_id'] = $this->request->post['payment_interswitch_pay_expired_status_id'];
        } else {
            $data['payment_interswitch_pay_expired_status_id'] = $this->config->get('payment_interswitch_pay_expired_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_failed_status_id'])) {
            $data['payment_interswitch_pay_failed_status_id'] = $this->request->post['payment_interswitch_pay_failed_status_id'];
        } else {
            $data['payment_interswitch_pay_failed_status_id'] = $this->config->get('payment_interswitch_pay_failed_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_pending_status_id'])) {
            $data['payment_interswitch_pay_pending_status_id'] = $this->request->post['payment_interswitch_pay_pending_status_id'];
        } else {
            $data['payment_interswitch_pay_pending_status_id'] = $this->config->get('payment_interswitch_pay_pending_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_processed_status_id'])) {
            $data['payment_interswitch_pay_processed_status_id'] = $this->request->post['payment_interswitch_pay_processed_status_id'];
        } else {
            $data['payment_interswitch_pay_processed_status_id'] = $this->config->get('payment_interswitch_pay_processed_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_refunded_status_id'])) {
            $data['payment_interswitch_pay_refunded_status_id'] = $this->request->post['payment_interswitch_pay_refunded_status_id'];
        } else {
            $data['payment_interswitch_pay_refunded_status_id'] = $this->config->get('payment_interswitch_pay_refunded_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_reversed_status_id'])) {
            $data['payment_interswitch_pay_reversed_status_id'] = $this->request->post['payment_interswitch_pay_reversed_status_id'];
        } else {
            $data['payment_interswitch_pay_reversed_status_id'] = $this->config->get('payment_interswitch_pay_reversed_status_id');
        }

        if (isset($this->request->post['payment_interswitch_pay_voided_status_id'])) {
            $data['payment_interswitch_pay_voided_status_id'] = $this->request->post['payment_interswitch_pay_voided_status_id'];
        } else {
            $data['payment_interswitch_pay_voided_status_id'] = $this->config->get('payment_interswitch_pay_voided_status_id');
        }

        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        if (isset($this->request->post['payment_interswitch_pay_geo_zone_id'])) {
            $data['payment_interswitch_pay_geo_zone_id'] = $this->request->post['payment_interswitch_pay_geo_zone_id'];
        } else {
            $data['payment_interswitch_pay_geo_zone_id'] = $this->config->get('payment_interswitch_pay_geo_zone_id');
        }

        $this->load->model('localisation/geo_zone');
        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        if (isset($this->request->post['payment_interswitch_pay_status'])) {
            $data['payment_interswitch_pay_status'] = $this->request->post['payment_interswitch_pay_status'];
        } else {
            $data['payment_interswitch_pay_status'] = $this->config->get('payment_interswitch_pay_status');
        }

        if (isset($this->request->post['payment_interswitch_pay_sort_order'])) {
            $data['payment_interswitch_pay_sort_order'] = $this->request->post['payment_interswitch_pay_sort_order'];
        } else {
            $data['payment_interswitch_pay_sort_order'] = $this->config->get('payment_interswitch_pay_sort_order');
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/payment/interswitch_pay', $data));
    }

    private function validate()
    {
        if (!$this->user->hasPermission('modify', 'extension/payment/interswitch_pay')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->request->post['payment_interswitch_pay_email']) {
            $this->error['email'] = $this->language->get('error_email');
        }

        return !$this->error;
    }
}
